local vsSrcUV <const> =
[[
	#version 110
	attribute vec2 position;
	attribute vec2 texcoord;
	varying vec2 uv;
	void main()
	{
		float x = 2.0*position.x/(640.0-1.0)-1.0;
		float y = 1.0-2.0*position.y/(480.0-1.0);
		gl_Position = vec4(x, y, 0.0, 1.0);
		uv = texcoord;
	}
]]

local fsSrcUV <const> =
[[
	#version 110
	uniform vec4 color;
	uniform sampler2D texture0;
	varying vec2 uv;
	void main()
	{
		vec4 texcolor = texture2D(texture0, uv);
		gl_FragColor = color * texcolor;
	}
]]

local shaderUV = newShader(vsSrcUV, fsSrcUV)

local GL_COLOR_BUFFER_BIT <const> = 0x00004000
local GL_FLOAT <const> = 0x1406
local GL_TRIANGLE_STRIP <const> = 0x0005
local GL_BLEND <const> = 0x0BE2
local GL_SRC_ALPHA <const> = 0x0302
local GL_ONE_MINUS_SRC_ALPHA <const> = 0x0303

local function drawRectUV(buffer, shader, texture)
	buffer:bind()
	shader:attrib("position", 2, GL_FLOAT, 4 * 4)
	shader:attrib("texcoord", 2, GL_FLOAT, 4 * 4, 2 * 4)
	shader:use()
	shader:setVec4("color", 1.0, 1.0, 1.0, 1.0)
	shader:setTexture("texture0", 0)
	texture:bind(0)
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4)
	texture:unbind()
	buffer:unbind()
end

return function(buffer, texture)
	glClearColor(0.0, 0.0, 0.0, 1.0)
	glClear(GL_COLOR_BUFFER_BIT)
	glViewport(0, 0, winW, winH)
	glEnable(GL_BLEND)
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
	drawRectUV(buffer, shaderUV, texture)
	glDisable(GL_BLEND)
end