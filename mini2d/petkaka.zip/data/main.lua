--[[
	windows�� https://liuliqiang.com/mini2d/petkaka.zip
	������Դ https://github.com/rwv/Rising-KaKa
	mini2d�γ� https://www.bilibili.com/cheese/play/ss31045
	��ҳ��demo https://liuliqiang.com/mini2d
	by liuliqiang 2025-06-15
--]]
local json = require "data.kaka"
local data = require "data.dkjson".decode(json)
local kaka = {}
local Stand
for k,v in pairs(data) do
	local Name = k
	local FrameCount = v.FrameCount
	local FrameRate = v.FrameRate
	local FrameHeight = v.FrameHeight
	local FrameWidth = v.FrameWidth
	local buffer = newBuffer((winW-FrameWidth)/2, (winH-FrameHeight)/2, FrameWidth, FrameHeight)
	local textures = {}
	for i = 0, FrameCount-1 do
		textures[i+1] = newTexture("data/kaka/"..Name.."/"..i..".png")
	end
	v.textures = textures
	v.buffer = buffer
	table.insert(kaka, v)
	if Name == "Stand" then Stand = #kaka end
end

local FrameCount, FrameRate, buffer, textures
local animIdx
local function selectAnim(idx)
	animIdx = idx
	FrameCount = kaka[animIdx].FrameCount
	FrameRate = kaka[animIdx].FrameRate
	buffer = kaka[animIdx].buffer
	textures = kaka[animIdx].textures
end
selectAnim(Stand)

local drawRect = require "data.draw"

local idx = 0
local skip = 0
local delay = 0
function draw()
	skip = skip + 1
	if skip >= 60/FrameRate then
		skip = 0
		idx = idx + 1
		if idx == FrameCount then
			idx = 0
			if animIdx == Stand then
				delay = delay + 1
				if delay == 2 then
					delay = 0
					selectAnim(math.random(1, #kaka))
				end
			else
				selectAnim(Stand)
			end
		end
	end
	drawRect(buffer, textures[idx + 1])
end

math.randomseed(os.time())